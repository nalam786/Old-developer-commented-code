// import React from 'react';
// import Form_footer from '../../components/edit_form/form_footer';
// import Form5 from '../../components/form_5';
// import URL from '../../URL';
// import {connect} from 'react-redux';
// import SideBar from '../../components/Sidebar';

// import GestureRecognizer, {swipeDirections} from 'react-native-swipe-gestures';
// import {
//   SafeArea_inputView,
//   StyleSheet,
//   ScrollView,
//   TextInput,
//   View,
//   Text,
//   StatusBar,
//   Image,
//   FlatList,
//   Picker,
//   TouchableOpacity,
// } from 'react-native';

// import {
//   Container,
//   Content,
//   Button,
//   Footer,
//   DatePicker,
//   Drawer,
//   Fab,
// } from 'native-base';

// import {
//   Header,
//   LearnMoreLinks,
//   Colors,
//   DebugInstructions,
//   ReloadInstructions,
// } from 'react-native/Libraries/NewAppScreen';

// const form_5 = props => {
//   const [data, setData] = React.useState({
//     didmount: 0,
//     rander_flag: 0,
//     footer: true,
//     farm_id: [],
//     removal_of_herbs: [],
//     seed_variety: [],
//     qty_per_acre: [],
//     seed_compamy: [],
//     sowing_date: [],
//     created_at: [],
//     modified_at: [],
//     gestureName: '',
//     bottomfooter: false,
//   });

//   renderForm = () => {
//     var d = new Date();
//     var y = d.getFullYear();
//     var m = d.getMonth();
//     var day = d.getDate();
//     var date = '';

//     if (day < 10 && m < 10) {
//       date = y + '-0' + m + '-0' + day;
//     } else {
//       if (day < 10) {
//         date = y + '-' + m + '-0' + day;
//       }
//       if (m < 10) {
//         date = y + '-0' + m + '-' + day;
//       }
//     }
//     data.farm_id.push({farm_id: ''});
//     data.removal_of_herbs.push({removal_of_herbs: ''});
//     data.seed_variety.push({seed_variety: ''});
//     data.qty_per_acre.push({qty_per_acre: ''});
//     data.seed_compamy.push({seed_compamy: ''});
//     data.sowing_date.push({sowing_date: date});

//     setData({
//       ...data,
//       removal_of_herbs: data.removal_of_herbs,
//     });
//   };

//   const sendform = async () => {
//     var d = new Date();
//     var y = d.getFullYear();
//     var m = d.getMonth();
//     var day = d.getDate();
//     var date = '';
//     if (day < 10 && m < 10) {
//       date = y + '-0' + m + '-0' + day;
//     } else {
//       if (day < 10) {
//         date = y + '-' + m + '-0' + day;
//       }
//       if (m < 10) {
//         date = y + '-0' + m + '-' + day;
//       }
//     }

//     for (let j = 0; j < data.removal_of_herbs.length; j++) {
//       if (data.removal_of_herbs[j] == '') {
//         alert('Please fill all the mandatory fields' + j);
//         return false;
//       }
//     }

//     for (let i = 0; i < data.removal_of_herbs.length; i++) {
//       let F_data = {};
//       let F_Data = {
//         f_farm_id: props.user_ids.farm_id,
//         f_removal_of_herbs: data.removal_of_herbs[i].removal_of_herbs,
//         f_seed_variety: data.seed_variety[i].seed_variety,
//         f_qty_per_acre: data.qty_per_acre[i].qty_per_acre,
//         f_sowing_date: data.sowing_date[i].sowing_date,
//         f_seed_compamy: data.sowing_date[i].seed_compamy,
//         f_created_by: props.user_ids.farm_id,
//         f_created_at: date,
//         f_modified_by: props.user_ids.farm_id,
//         f_modified_at: date,
//       };
//       console.log('Seeds Create/ API Calling', F_Data);

//       await fetch(URL.url + 'seeds/seeds_create', {
//         method: 'POST',

//         headers: {
//           Accept: 'application/json',
//           'Content-Type': 'application/json',
//         },

//         body: JSON.stringify({F_Data}),
//       })
//         .then(res => res.json())

//         .then(resjson => {
//           if (resjson.Message == 'New Seed Created Successfully') {
//             props.navigation.navigate('irrigation_form_edit');
//           }

//           alert(resjson.Message);
//         })

//         .catch(err => {
//           console.log('Seed API Failed', err);
//           alert('Failed to Submit Data: ' + err);
//         });
//     }
//   };

//   if (props.flag.flag == 'seed_create') {
//     switch (props.flag.s_key) {
//       case 1:
//         data.removal_of_herbs[props.flag.index].removal_of_herbs =
//           props.flag.value;
//         break;
//       case 2:
//         data.seed_variety[props.flag.index].seed_variety = props.flag.value;
//         break;
//       case 3:
//         data.qty_per_acre[props.flag.index].qty_per_acre = props.flag.value;
//         break;
//       case 4:
//         data.sowing_date[props.flag.index].sowing_date = props.flag.value;
//         break;
//         break;
//       case 5:
//         data.seed_compamy[props.flag.index].seed_compamy = props.flag.value;
//         break;
//       default:
//         break;
//     }

//     props.changeFlag({
//       flag: 0,
//       s_key: 's_key',
//       index: 'index',
//       value: 'value',
//     });

//     console.log('Props Flag Changed to 0');
//   }

//   if (props.flag.flag == 'seed_delete') {
//     data.farm_id.splice(props.flag.index, 1);
//     data.removal_of_herbs.splice(props.flag.index, 1);
//     data.seed_variety.splice(props.flag.index, 1);
//     data.qty_per_acre.splice(props.flag.index, 1);
//     data.sowing_date.splice(props.flag.index, 1);
//     data.seed_compamy.splice(props.flag.index, 1);

//     if (data.rander_flag == 0) {
//       this.renderForm();
//       data.rander_flag = 1;

//       setData({
//         ...data,
//         removal_of_herbs: data.removal_of_herbs,
//         rander_flag: 1,
//       });
//     }

//     props.changeFlag({
//       flag: 0,
//       s_key: 's_key',
//       index: 'index',
//       value: 'value',
//     });
//   }

//   if (data.didmount == 0) {
//     this.renderForm();
//     data.didmount = 1;

//     setData({
//       ...data,
//       didmount: 1,
//     });
//   }
//   if (props.flag.flag == 'seed_hide/show_footer') {
//     // alert(3456)

//     if (props.flag.value == 'hide' && data.rander_flag == 0) {
//       // alert(3456)
//       data.rander_flag = 1;
//       setData({
//         ...data,
//         footer: false,
//         rander_flag: 1,
//       });
//     }
//     if (props.flag.value == 'show' && data.rander_flag == 1) {
//       data.rander_flag = 0;
//       // alert(33333)
//       setData({
//         ...data,
//         footer: true,
//         rander_flag: 0,
//       });
//     }
//   }
//   //1. add this bottom footer
//   const bottom_footer = () => {
//     if (data.bottomfooter == true) {
//       return data.footer ? (
//         <View
//           style={{
//             position: 'absolute',
//             left: 0,
//             right: 0,
//             bottom: 0,
//           }}>
//           <Fab
//             active={false}
//             containerStyle={{
//               marginTop: -50,
//             }}
//             style={{
//               backgroundColor: 'white',
//               zIndex: 11,
//               width: 40,
//               height: 40,
//             }}
//             position="topLeft"
//             onPress={() =>
//               setData({
//                 ...data,
//                 bottomfooter: !data.bottomfooter,
//               })
//             }>
//             <Image
//               source={require('../../assets/img/arow_up.png')}
//               style={{
//                 width: 30,
//                 height: 30,
//                 resizeMode: 'contain',
//                 transform: [{rotate: '180deg'}],
//               }}
//             />
//           </Fab>
//           <View>
//             <Form_footer form_no={3} nav={props} />
//           </View>
//         </View>
//       ) : (
//         <View />
//       );
//     } else {
//       return null;
//     }
//   };
//   //2. add this bottom before
//   const fabbuttonbefor = () => {
//     if (data.bottomfooter == false) {
//       return (
//         <Fab
//           active={false}
//           direction="up"
//           containerStyle={{}}
//           style={{backgroundColor: 'white', zIndex: 11, width: 40, height: 40}}
//           position="bottomRight"
//           onPress={() =>
//             setData({
//               ...data,
//               bottomfooter: !data.bottomfooter,
//             })
//           }>
//           <Image
//             source={require('../../assets/img/arow_up.png')}
//             style={{
//               width: 30,
//               height: 30,
//               resizeMode: 'contain',
//             }}
//           />
//         </Fab>
//       );
//     }
//   };
//   const closeDrawer = () => {
//     this.drawer._root.close();
//   };
//   const openDrawer = () => {
//     // console.log("i am")
//     this.drawer._root.open();
//   };
//   return (
//     <Drawer
//       ref={ref => {
//         this.drawer = ref;
//       }}
//       openDrawerOffset={0.3}
//       content={<SideBar nav={props} close={() => this.closeDrawer()} />}>
//       <Container>
//         <View style={{flex: 1}}>
//           {/* //3. call  this bottom before */}
//           {fabbuttonbefor()}
//           <ScrollView style={styles.scrollView}>
//             <View style={[styles.header]}>
//               <View
//                 style={{
//                   flex: 2,
//                   flexDirection: 'row',
//                   justifyContent: 'space-between',
//                 }}>
//                 <View
//                   style={{
//                     flex: 1,
//                     flexDirection: 'column',
//                     justifyContent: 'center',
//                   }}>
//                   <TouchableOpacity
//                     style={{
//                       flex: 1,
//                       flexDirection: 'column',
//                       justifyContent: 'center',
//                     }}
//                     onPress={() => openDrawer()}>
//                     <Image
//                       source={require('../../assets/img/menu.png')}
//                       style={{
//                         width: '30%',
//                         height: 20,
//                         resizeMode: 'stretch',
//                         marginLeft: 10,
//                       }}
//                     />
//                   </TouchableOpacity>
//                 </View>

//                 <View
//                   style={{
//                     flex: 2,
//                     justifyContent: 'center',
//                     alignItems: 'center',
//                   }}>
//                   <Text
//                     style={{color: 'white', fontSize: 20, fontWeight: '800'}}>
//                     Seeds
//                   </Text>
//                   <Text
//                     style={{color: 'white', fontSize: 20, fontWeight: '800'}}>
//                     بیج
//                   </Text>
//                 </View>
//                 <View
//                   style={{
//                     width: '10%',
//                     flex: 1,
//                     flexDirection: 'column',
//                     justifyContent: 'center',
//                   }}>
//                   <View />
//                 </View>
//               </View>
//             </View>

//             <View
//               style={{
//                 flex: 1,
//                 flexDirection: 'column',
//                 justifyContent: 'space-between',
//               }}>
//               <View style={{alignSelf: 'center', marginTop: 30, width: '95%'}}>
//                 {data.removal_of_herbs.map((
//                   removal_of_herbs,
//                   keys, //you can use  mandatory field here
//                 ) => (
//                   <Form5
//                     index={keys + 1}
//                     farm_id={data.farm_id}
//                     f_removal_of_herbs={data.removal_of_herbs}
//                     f_seed_variety={data.seed_variety}
//                     f_qty_per_acre={data.qty_per_acre}
//                     f_sowing_date={data.sowing_date}
//                     f_seed_compamy={data.seed_compamy}
//                     index2={keys}
//                   />
//                 ))}
//               </View>
//             </View>

//             <View>
//               <Button
//                 onPress={() => renderForm()}
//                 style={[styles.input_button]}
//                 full>
//                 <Text style={{color: 'white', fontSize: 15, fontWeight: '800'}}>
//                   Add form (معلومات شامل کریں)
//                 </Text>
//               </Button>
//             </View>

//             <View style={{marginBottom: '2%'}}>
//               <Button
//                 onPress={() => sendform()}
//                 style={[styles.input_button, {marginBottom: 300}]}
//                 full>
//                 <Text style={{color: 'white', fontSize: 15, fontWeight: '800'}}>
//                   Submit (جمع کرائیں)
//                 </Text>
//               </Button>
//             </View>

//             {/* {
//             data.footer ? (
//               <Form_footer form_no={3} nav={props} />
//             ):(<View/>)
//           } */}
//           </ScrollView>
//         </View>
//         {bottom_footer()}
//       </Container>
//     </Drawer>
//   );
// };

// const styles = StyleSheet.create({
//   box: {
//     backgroundColor: '#05422b',
//     width: '100%',
//     justifyContent: 'center',
//     alignItems: 'center',
//     height: 80,

//     // marginTop:50,
//   },
//   paragraph: {
//     backgroundColor: '#359814',
//     fontSize: 8,

//     // marginTop:50,
//   },
//   header: {
//     backgroundColor: '#359814',
//     height: 50,
//     // marginTop:50,
//   },
//   cart: {
//     backgroundColor: '#d7f3db',
//     borderRadius: 10,
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     paddingLeft: '5%',
//     paddingRight: '5%',
//     // paddingTop:'3%',
//     paddingVertical: '3%',
//   },
//   cartbody: {
//     paddingLeft: 20,
//     paddingRight: 20,
//   },
//   input_button: {
//     height: 40,
//     width: 300,
//     backgroundColor: '#05422b',
//     color: 'red',
//     alignSelf: 'center',
//     margin: 0,
//     marginTop: 30,
//   },
//   input_phone_code: {
//     height: 35,
//     width: 65,
//     borderTopWidth: 0,
//     borderLeftWidth: 0,
//     borderRightWidth: 0,
//     borderBottomColor: 'gray',
//     borderWidth: 1,
//     marginBottom: 30,
//     marginRight: 5,
//   },
//   input_phone: {
//     height: 35,
//     width: 230,
//     borderTopWidth: 0,
//     borderLeftWidth: 0,
//     borderRightWidth: 0,
//     borderBottomColor: 'gray',
//     borderWidth: 1,
//     marginBottom: 20,
//   },
//   input_email: {
//     height: '12%',
//     width: '95%',
//     borderTopWidth: 0,
//     borderLeftWidth: 0,
//     borderRightWidth: 0,
//     borderBottomColor: 'gray',
//     borderWidth: 1,
//     marginBottom: 30,
//     alignSelf: 'center',
//   },
//   input_: {
//     height: 40,
//     width: 300,
//     borderTopWidth: 0,
//     borderLeftWidth: 0,
//     borderRightWidth: 0,
//     borderBottomColor: 'gray',
//     borderWidth: 1,
//     marginBottom: 20,
//   },
//   green_h6_start: {
//     color: '#000',
//     fontSize: 13,
//     fontWeight: '400',
//     alignSelf: 'flex-start',
//     // marginTop:50,
//   },
//   green_h2_start: {
//     color: '#000',
//     fontWeight: '700',
//     fontSize: 15,
//     alignSelf: 'flex-start',
//     // marginTop:50,
//   },

//   scrollView: {
//     backgroundColor: Colors.lighter,
//     height: '100%',
//   },
//   engine: {
//     position: 'absolute',
//     right: 0,
//   },
//   body: {
//     backgroundColor: Colors.white,
//   },
//   sectionContainer: {
//     marginTop: 32,
//     paddingHorizontal: 24,
//   },
//   sectionTitle: {
//     fontSize: 24,
//     fontWeight: '600',
//     color: Colors.black,
//   },
//   sectionDescription: {
//     marginTop: 8,
//     fontSize: 18,
//     fontWeight: '400',
//     color: Colors.dark,
//   },
//   highlight: {
//     fontWeight: '700',
//   },
//   footer: {
//     color: Colors.dark,
//     fontSize: 12,
//     fontWeight: '600',
//     padding: 4,
//     paddingRight: 12,
//     textAlign: 'right',
//   },
// });

// const mapStateToProps = state => {
//   return {
//     flag: state.flag,
//     signup: state.signup_redux,
//     user_ids: state.user_id_redux,
//   };
// };

// const mapDispatchToProps = dispatch => {
//   return {
//     changeFlag: data => {
//       dispatch({type: 'CHANGE_FLAG', payload: data});
//     },
//     changeSignup: data => {
//       dispatch({type: 'SIGNUP_DATA', payload: data});
//     },
//     user_id: data => {
//       dispatch({type: 'USER_ID', payload: data});
//     },
//   };
// };

// export default connect(
//   mapStateToProps,
//   mapDispatchToProps,
// )(form_5);
import React from 'react';
import Form_footer from '../../components/edit_form/form_footer';
import Form5 from '../../components/edit_form/form_5';
import URL from '../../URL';
import {connect} from 'react-redux';

import {Container, Content, Button, Footer, DatePicker, Fab} from 'native-base';

import {
  SafeArea_inputView,
  StyleSheet,
  ScrollView,
  TextInput,
  View,
  Text,
  StatusBar,
  Image,
  FlatList,
  Picker,
} from 'react-native';

import {
  Header,
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';

const form_2 = props => {
  const [data, setData] = React.useState({
    didmount: 0,
    rander_flag: 0,

    land_prereration_id: [],
    prepared_field_irrigation: [],
    soil_type: [],
    laser_levelled: [],
    levelled_date: [],
    first_irrigation: [],
    irrigation_frequency: [],
    farm_distance_watercourse: [],
    bottomfooter: true,
    footer: true,
  });

  renderForm = () => {
    data.land_prereration_id.push({land_prereration_id: 0});
    data.prepared_field_irrigation.push({prepared_field_irrigation: ''});
    data.soil_type.push({soil_type: ''});
    data.laser_levelled.push({laser_levelled: ''});
    data.levelled_date.push({levelled_date: ''});
    data.first_irrigation.push({first_irrigation: ''});
    data.irrigation_frequency.push({irrigation_frequesncy: ''});
    data.farm_distance_watercourse.push({farm_distance_watercourse: ''});

    setData({
      ...data,
      prepared_field_irrigation: data.prepared_field_irrigation,
    });
  };

  const sendform = async () => {
    var d = new Date();
    var y = d.getFullYear();
    var m = d.getMonth();
    var day = d.getDate();
    var date = '';
    if (day < 10 && m < 10) {
      date = y + '-0' + m + '-0' + day;
    } else {
      if (day < 10) {
        date = y + '-' + m + '-0' + day;
      }
      if (m < 10) {
        date = y + '-0' + m + '-' + day;
      }
    }

    for (let j = 0; j < data.prepared_field_irrigation.length; j++) {
      if (data.prepared_field_irrigation[j] == '') {
        alert('Please fill all the mandatory fields' + j);
        return false;
      }
    }

    for (let i = 0; i < data.prepared_field_irrigation.length; i++) {
      let F_data = {};
      let F_Data = {
        f_farm_id: 2, //props.user_ids.update_farm_id,
        f_land_prereration_id: data.land_prereration_id[i].land_prereration_id,
        f_prepared_field_irrigation:
          data.prepared_field_irrigation[i].prepared_field_irrigation,
        f_soil_type: data.soil_type[i].soil_type,
        f_laser_levelled: data.laser_levelled[i].laser_levelled,
        f_levelled_date: data.levelled_date[i].levelled_date,
        f_first_irrigation: data.first_irrigation[i].first_irrigation,
        f_irrigation_frequency:
          data.irrigation_frequency[i].irrigation_frequency,
        f_farm_distance_watercourse:
          data.farm_distance_watercourse[i].farm_distance_watercourse,
        f_created_by: props.user_ids.farm_id,
        f_created_at: date,
        f_modified_by: props.user_ids.farm_id,
        f_modified_at: date,
      };

      console.log('Land Preperation Create API Calling', F_Data);

      await fetch(URL.url + 'land_preperations/land_preperations_update', {
        method: 'POST',

        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },

        body: JSON.stringify({F_Data}),
      })
        .then(res => res.json())

        .then(resjson => {
          if (resjson.Message == 'New Land Preperation Created Successfully') {
            // props.navigation.navigate('seed_form');
          }

          alert(resjson.Message);
        })

        .catch(err => {
          console.log('Land Preperation API Failed', err);
          alert('Failed to Submit Data: ' + err);
        });
    }
  };

  if (props.flag.flag == 1) {
    switch (props.flag.s_key) {
      case 1:
        data.prepared_field_irrigation[
          props.flag.index
        ].prepared_field_irrigation = props.flag.value;
        break;
      case 2:
        data.soil_type[props.flag.index].soil_type = props.flag.value;
        break;
      case 3:
        data.laser_levelled[props.flag.index].laser_levelled = props.flag.value;
        break;
      case 4:
        data.levelled_date[props.flag.index].levelled_date = props.flag.value;
        break;
      case 5:
        data.first_irrigation[props.flag.index].first_irrigation =
          props.flag.value;
        break;
      case 6:
        data.irrigation_frequency[props.flag.index].irrigation_frequesncy =
          props.flag.value;
        break;
      case 7:
        data.farm_distance_watercourse[
          props.flag.index
        ].farm_distance_watercourse = props.flag.value;
        break;
      default:
        break;
    }

    props.changeFlag({
      flag: 0,
      s_key: 's_key',
      index: 'index',
      value: 'value',
    });

    console.log('Props Flag Changed to 0');
  }

  if (props.flag.flag == 2) {
    if (data.land_prereration_id[props.flag.index].land_prereration_id == 0) {
      data.prepared_field_irrigation.splice(props.flag.index, 1);
      data.soil_type.splice(props.flag.index, 1);
      data.laser_levelled.splice(props.flag.index, 1);
      data.levelled_date.splice(props.flag.index, 1);
      data.first_irrigation.splice(props.flag.index, 1);
      data.irrigation_frequency.splice(props.flag.index, 1);
      data.farm_distance_watercourse.splice(props.flag.index, 1);
    } else {
      this.del_landpreperation(
        data.land_prereration_id[props.flag.index].land_prereration_id,
      );
      data.prepared_field_irrigation.splice(props.flag.index, 1);
      data.soil_type.splice(props.flag.index, 1);
      data.laser_levelled.splice(props.flag.index, 1);
      data.levelled_date.splice(props.flag.index, 1);
      data.first_irrigation.splice(props.flag.index, 1);
      data.irrigation_frequency.splice(props.flag.index, 1);
      data.farm_distance_watercourse.splice(props.flag.index, 1);
    }
    if (data.rander_flag == 0) {
      // this.test();

      // this.renderForm();
      data.rander_flag = 1;
      setData({
        ...data,
        prepared_field_irrigation: data.prepared_field_irrigation,
        rander_flag: 1,
      });
    }
    props.changeFlag({
      flag: 0,
      s_key: 's_key',
      index: 'index',
      value: 'value',
    });
  }
  del_landpreperation = async land_preperation_id => {
    let F_Data = {
      f_land_preperation_id: land_preperation_id, //props.user_ids.update_farm_id,
    };

    console.log('Get Farm API Calling: ', F_Data);

    await fetch(URL.url + 'land_preperations/land_preperations_delete', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({F_Data}),
    })
      .then(res => res.json())
      .then(resjson => {
        console.log(resjson);
        if (
          resjson.Message == 'Land Preperation of Farm Deleted Successfully'
        ) {
          alert(resjson.Message);
        }
      })
      .catch(err => {
        console.log('failed', err);
      });
  };
  const get_landpreperation = async () => {
    console.log(props);
    let data = {
      f_farm_id: props.user_ids.update_farm_id,
    };
    // {"data" : {
    //   "f_farm_id":"455"
    // }}

    console.log('Get Farm API Calling: ', data);

    await fetch(URL.url + 'seeds/seeds', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({data}),
    })
      .then(res => res.json())
      .then(resjson => {
        console.log('data', JSON.stringify(resjson));
        if (resjson.Message == 'Land Preperation of Farm Get Successfully') {
          resjson.data.forEach(element => {
            data.land_prereration_id.push({land_prereration_id: element.id});
            data.prepared_field_irrigation.push({
              prepared_field_irrigation: element.prepared_field_irrigation,
            });
            data.soil_type.push({soil_type: element.soil_type});
            data.laser_levelled.push({laser_levelled: element.laser_levelled});
            data.levelled_date.push({levelled_date: element.levelled_date});
            data.first_irrigation.push({
              first_irrigation: element.first_irrigation,
            });
            data.irrigation_frequency.push({
              irrigation_frequesncy: element.irrigation_frequency,
            });
            data.farm_distance_watercourse.push({
              farm_distance_watercourse: element.farm_distance_watercourse,
            });
          });
          setData({
            ...data,
            prepared_field_irrigation: data.prepared_field_irrigation,
          });
        }
      })
      .catch(err => {
        console.log('failed', err);
      });
  };
  if (data.didmount == 0) {
    // this.renderForm();
    get_landpreperation();
    data.didmount = 1;

    setData({
      ...data,
      didmount: 1,
    });
  }
  //1. add this bottom footer
  const bottom_footer = () => {
    if (data.bottomfooter == true) {
      return data.footer ? (
        <View
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            bottom: 0,
          }}>
          <Fab
            active={false}
            containerStyle={{
              marginTop: -50,
            }}
            style={{
              backgroundColor: 'white',
              zIndex: 11,
              width: 40,
              height: 40,
            }}
            position="topLeft"
            onPress={() =>
              setData({
                ...data,
                bottomfooter: !data.bottomfooter,
              })
            }>
            <Image
              source={require('../../assets/img/arow_up.png')}
              style={{
                width: 30,
                height: 30,
                resizeMode: 'contain',
                transform: [{rotate: '180deg'}],
              }}
            />
          </Fab>
          <View>
            <Form_footer form_no={2} nav={props} />
          </View>
        </View>
      ) : (
        <View />
      );
    } else {
      return null;
    }
  };
  //2. add this bottom before
  const fabbuttonbefor = () => {
    if (data.bottomfooter == false) {
      return (
        <Fab
          active={false}
          direction="up"
          containerStyle={{}}
          style={{backgroundColor: 'white', zIndex: 11, width: 40, height: 40}}
          position="bottomRight"
          onPress={() =>
            setData({
              ...data,
              bottomfooter: !data.bottomfooter,
            })
          }>
          <Image
            source={require('../../assets/img/arow_up.png')}
            style={{
              width: 30,
              height: 30,
              resizeMode: 'contain',
            }}
          />
        </Fab>
      );
    }
  };
  return (
    <>
      {fabbuttonbefor()}
      <ScrollView style={styles.scrollView}>
        <View style={[styles.header]}>
          <View
            style={{
              flex: 2,
              flexDirection: 'row',
              justifyContent: 'space-between',
            }}>
            <View
              style={{
                flex: 1,
                flexDirection: 'column',
                justifyContent: 'center',
              }}>
              <Image
                source={require('../../assets/img/menu.png')}
                style={{
                  width: '30%',
                  height: 30,
                  resizeMode: 'stretch',
                  marginLeft: 10,
                }}
              />
            </View>

            <View
              style={{flex: 2, justifyContent: 'center', alignItems: 'center'}}>
              <Text style={{color: 'white', fontSize: 20, fontWeight: '800'}}>
                Seeds
              </Text>
            </View>
            <View
              style={{
                width: '10%',
                flex: 1,
                flexDirection: 'column',
                justifyContent: 'center',
              }}>
              <View />
            </View>
          </View>
        </View>

        <View
          style={{
            flex: 1,
            flexDirection: 'column',
            justifyContent: 'space-between',
          }}>
          <View style={{alignSelf: 'center', marginTop: 30, width: '95%'}}>
            {data.prepared_field_irrigation.map((
              prepared_field_irrigation,
              keys, //you can use  mandatory field here
            ) => (
              <Form5
                index={keys + 1}
                farm_id={data.farm_id}
                f_prepared_field_irrigation={data.prepared_field_irrigation}
                f_soil_type={data.soil_type}
                f_laser_levelled={data.laser_levelled}
                f_levelled_date={data.levelled_date}
                f_first_irrigation={data.first_irrigation}
                f_irrigation_frequency={data.irrigation_frequency}
                f_farm_distance_watercourse={data.farm_distance_watercourse}
                index2={keys}
              />
            ))}
          </View>
        </View>

        <View>
          <Button
            onPress={() => renderForm()}
            style={[styles.input_button]}
            full>
            <Text style={{color: 'white', fontSize: 15, fontWeight: '800'}}>
              ADD FORM
            </Text>
          </Button>
        </View>

        <View>
          <Button onPress={() => sendform()} style={[styles.input_button]} full>
            <Text style={{color: 'white', fontSize: 15, fontWeight: '800'}}>
              SUBMIT
            </Text>
          </Button>
        </View>

        {/* <Form_footer form_no={2} nav={props} /> */}
      </ScrollView>
      {bottom_footer()}
    </>
  );
};

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#359814',
    height: 70,
  },

  input_button: {
    height: 40,
    width: 300,
    backgroundColor: '#05422b',
    color: 'red',
    alignSelf: 'center',
    margin: 0,
    marginBottom: 20,
  },

  scrollView: {
    backgroundColor: Colors.lighter,
    height: '100%',
  },

  body: {
    backgroundColor: Colors.white,
  },
});

const mapStateToProps = state => {
  return {
    flag: state.flag,
    signup: state.signup_redux,
    user_ids: state.user_id_redux,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    changeFlag: data => {
      dispatch({type: 'CHANGE_FLAG', payload: data});
    },
    changeSignup: data => {
      dispatch({type: 'SIGNUP_DATA', payload: data});
    },
    user_id: data => {
      dispatch({type: 'USER_ID', payload: data});
    },
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(form_2);
